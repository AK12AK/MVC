<?php
  class Pages extends Controller {
    public function __construct(){
     
    }
    
    public function index(){
      // print_r("fsdfs");
      // exit;
      $data = [
        'title' => 'STUDENT DATABASE',
      ];
     
      $this->view('pages/registration', $data);
    }



    public function mentor(){
      // print_r("fsdfs");
      // exit;
      $data = [
        'title' => 'mentor details!',
      ];
     
      $this->view('pages/mentor_t', $data);
    }



    public function nav()
    {
      $nav =[
   'message' => 'nav'
      ];
     $this->view('pages/nav' , $nav);
       }

      
       public function student_details()
      {
        $data =[

          'message' => 'stu'
        ];
         $this->view('pages/student' , $data);
      }


      public function table()
      {
        $data =[

          'message' => 'table'
        ];
  
        $this->view('pages/table' , $data);
      }

   
      
    public function student_save()
    {
      if(($_POST['student'] &&  $_POST['stdID']))
      {
        // print_r("sfdfsf");
        // exit;
      $postData = $_POST;
      $model = $this->model('Model');
      $data = $model->Sinsert($postData);

      // print_r($_POST['student']);
      // exit;
      $data =[
        'data' => 'Registered successfully!'
      ];
      $this->view('pages/student' , $data);
    }
    else
    {   
      $try =[
        'data' => 'Try again later!'
      ];
      $this->view('pages/student' , $try);
    }
    
  }



    public function save_mentor()
    {
      $model = $this->model('Model');
      $postData = $_POST;
      if(isset($_POST['sub']))
      {
     $data =  $model->Tinsert($postData);
     $data12 = $data[0]->id;
     if($_POST['teachID'] ==  $data12)
     {
      $data =[
              'message' => 'Try again!'
      ];
     $this->view('pages/mentor_t' , $data);
     }
     if($_POST['teachID'] !=  $data12)
     {
      $data1 =[
        'message' => 'Registered successfully'
      ];
      $this->view('pages/mentor_t' , $data1);
     }
      }
    }


    public function tables()
    {

      // print_r($_POST['pagination']);
      // exit;
      $model = $this->model('Model');
      $postData = $_POST;
      if(isset($_POST['disp']))
      {
      $data = $model->mentor($postData);
      // print_r($data);
      // exit;
      $this->view('pages/table', $data);
      }
    }

    // public function save()
    // {
    //   $model = $this->model('Model');
    //   $postData = $_POST;
    //   if(isset($_POST['submit']))
    //   {
    //   $data = $model->Sinsert($postData);
    //   $student =[
    //     'message' => 'Registered successfully!'
    //   ];
    //   $this->view('pages/student' , $student);
    //   }
    //   else
    //   {
    //     $student =[
    //       'message' => 'Try again later!'
    //     ];  
    //     $this->view('pages/student' , $student);
    // }
    // }

    public function register()
    {

  if (isset($_POST['username'])) {
       
        $username = stripslashes($_POST['username']);
      
      //  print_r($username);
      //  exit;
        $email    = $_POST['email'];
        $password = stripslashes($_POST['password']);
        // print_r($password);
        // exit;
        
        $create_datetime = date("Y-m-d H:i:s");

        $array1233 = [ $username ,  $email , $password ,$create_datetime ];
        // print_r($array1233);
        // exit;
        $model = $this->model('Model');

        $data123 = $model->register($array1233);

        $data =[

          "message" => "Registered successfully"
        ];

        $this->view('pages/registration' , $data);
 
    }
    }



    public function logout()

    {
     unset($_SESSION['user']);
     $data=
     [
       'title' => 'logout'
     ];
     $this->view('pages/login', $data);
    }

    public function logincheck()
    {
      $data = [
        'title' => 'login'
      ];

      $this->view('pages/login', $data);

    }




    public function login()
    {  
      if (isset($_POST['username'])) {
        $username = stripslashes($_POST['username']);
       
        $password = stripslashes($_POST['password']);
        $array = [$username , $password];
        $model = $this->model('Model');
        $data  =  $model->login($array);
         $name = $data[0]->username;
         $pss = $data[0]->password; 
        if(  $username == $name && $password == $pss)
        {

          session_start();

          $_SESSION['user'] = $name;
      
         $this->view('pages/mentor_t', $name ,  $_SESSION['user']);
        }
        else
        {
          $data=[
            'message' => 'login failed!'
          ];
          $this->view('pages/login', $data);
        }
    } 
    else
    {
    $data = [
      'title' => 'login'
    ];
    $this->view('pages/login', $data);
    }
  }




    public function disp()
    {
      $model = $this->model('Model');
      $postData =$_POST;
      $post=$model->display1($postData);
      $data=[
        'posts'=>$post
      ];
   
    $this->view('pages/display',$data);
    }

    public function registration()
    {
      $data = [
        'title' => 'registration'
      ];

      $this->view('pages/registration', $data);

    }

     
    public function about(){
      $data = [
        'title' => 'About Us'
      ];

      $this->view('pages/about', $data);
    }
  }
