<?php
class Model extends Database{


  public function mentor($postData)
  {
    if(isset($postData['disp'])){

      // echo "working";
      // exit;
      $ID = $_POST['id'];

      $limit =$_POST['pagination'];
      if(empty($limit))
      {
     
        $limit = 5;
      }
      
      $this->query("SELECT student_d.std_name, teachers.name FROM student_d JOIN teachers ON student_d.id_tchr = teachers.id WHERE teachers.id =  $ID LIMIT $limit");
      return $this->resultSet();

      //  foreach($id as $da)
      //  {
      //    echo $da;
      //  }

      //  $data= $this->query("SELECT student_d.std_name, teachers.name FROM student_d JOIN teachers ON student_d.id_tchr = teachers.id");

     

    }
  }

  public function register($array1233)
  {

    // print_r($array1233[3]);
    // exit;
     $username = $array1233[0];
     
     $email = $array1233[1]; 
     
     $pass = $array1233[2]; 
     
     $DT = $array1233[3];

    
     $this->query("INSERT INTO users(username,email,password,create_datetime)
    VALUES('$username','$email','$pass','$DT')");
    // $this->execute();
    return $this->execute();

    
  }


  public function login($array)
  {
    $username = $array[0];

    $password = $array[1];
    
    $this->query("SELECT * FROM users WHERE username = '$username' AND password = '$password'");
    return $this->resultSet();
    // print_r($data);
    // exit;
  }


    public function Sinsert($postData){
      if(isset($postData['submit'])){
        // echo "student";
        // exit;
      $student=$postData['student'];
           $stdID=$postData['stdID'];
      
      $this->query("INSERT INTO student_d(std_name,id_tchr)VALUES('$student','$stdID')");
            return $this->execute();
      }
    }
      public function Tinsert($postData){
         
            // print_r("teacher");
            // exit;
          $teacher=$postData['teacher'];
          $teachID=$postData['teachID'];
          $disg=$postData['disg'];
         $ID = $this->query("SELECT * FROM teachers WHERE id = '$teachID' ");
         $ID = $this->resultSet();
          
            if($ID[0]->id == $teachID)
            {
              return $this->resultSet();
            }
            
        //  print_r($ID[0]->id);
        //  exit;
         
            $teacher=$postData['teacher'];
            $teachID=$postData['teachID'];
            $disg=$postData['disg'];

          $this->query("INSERT INTO teachers(name,id,disg)VALUES('$teacher','$teachID','$disg')");
          return $this->execute();

         
        }
        public function display1($postData){
          if(isset($postData['nop'])){
                   $this->query("SELECT name, std_name    FROM teachers
                   INNER JOIN students ON teachers.id=students.id where teachers.id = 2");
                   return $this->resultSet();
                   }
                  }
                  
                  }
   
      // $row = $resu -> fetch_assoc();
      // printf ("%s (%s)\n", $row["name"], $row["id"]);
                          
              // while($rec=$resu->fetch_assoc())
              // {
                
              //     echo "Name : ". $rec['name']."<br>";
                
              //  }
              
        
         
        //     $resul= $this->execute("SELECT name
        // FROM teachers
        // INNER JOIN students
        // ON teachers.id($id)=students.id($id);");
        // echo "name";
  //  $result=$this->query($resul);
          
        // if ($result->num_rows > 0){
                        
        //     while($rec=$result->fetch())
        //     {
              
        //         echo "Name : ". $rec['name']."<br>";
        //         echo "std name : ".$rec['std_name']."<br>";
               
        //      }
        //     }
        //   }
        // }
      //die;
     // $this->prepare
      // var_dump($postData);
      // die('s');   
      //    if(isset($postData['submit'])){
//                $teacher=$postData['teacher'];
//            $teachID=$postData['teachID'];
//                $student=$postData['student'];
//                 $stdID=$postData['stdID'];
//                $stmt = $this->prepare("INSERT INTO students(std_name,id)VALUES (?, ?)");
//               $stmt->bind("si", $student, $stdID);
//               var_dump($stmt);
//            $sql=$this->query($stmt);
// var_dump($sql);
            //     $sql=$this->query("INSERT INTO students(std_name,id)VALUES('$student','$stdID')");
            //     var_dump($sql);
               
           
      

//  $sql="INSERT INTO students(std_name,id)VALUES('$student','$stdID')";
// $sql="INSERT INTO teachers(id,name,disg)VALUES('$teacher','$teachID')";

