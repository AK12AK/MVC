<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'sqluser');
  define('DB_PASS', 'BXNq36*30%ie');
  define('DB_NAME', 'file');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/mvc/');
  // Site Name
  define('SITENAME', 'STUDENT DETAILS');