<?php
    session_start();
    if(!isset($_SESSION["user"])) {
        header("Location: login.php");
        exit();
    }
?>
<?php require APPROOT . '/views/inc/header.php'; ?>
   
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
     integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
     <link rel="stylesheet" href="<?php echo URLROOT . 'css/teacher.css'?>"/>
<style>
 
</style>
<?php
    include('nav.php');
?>    
  </head>
  <body>
 
<div class="container">
  <div class="row justify-content-md-center">
    <div class="col-4">
    <form action="<?php echo URLROOT. 'pages/save_mentor' ?>" method="post">
   <div class="form-group" style="margin-top: 7em;">
    <h1>Mentor Registration</h1>
    </div>
   <div class="form-group">
     <div>
   <label for="">Mentor Name:</label>
</div>
    <input type="text" name="teacher" placeholder="Enter Mentor Name" required>
    </div>
   <div class="form-group">
     <div>
     <label for="">ID:</label>
</div>
   <input type="text" name="teachID" placeholder="Enter Id" required>
    </div>
   <div class="form-group">
     <div>
   <label for="">Disgnation:</label>
</div>
   <input type="text" name="disg" placeholder="Enter Disgnation" required>
    </div>
    <?php if(isset($data))
      {
          $data = $data['message'];
          if($data != 'd')
          {
          echo "<p> $data </p>";
          }
      }
    //   if(isset($data1))
    //   {
    //       $data12 = $data1['message'];
    //       echo "<p class='gree'> $data12 </p>";
    //   }
      ?>
      
   <!-- <input type="submit" name="sub" > -->
   <button class="button-252" type="submit" name="sub" role="button">Submit</button>
    </form>
    </div>
  
   
   <!-- <div class="col-6">col-8</div>
  <div class="col-6">col-4</div> -->
  <!-- </form>
    </div>
    
    <div class="col-4">
    <h1>Student Details</h1>
    <form action="<?php echo URLROOT. 'pages/save' ?>" method="post">
    <div class="form-group">
      <div>
      <label>Student Name:</label>
</div>
    <input type="text" name="student" placeholder="Enter Student Name">
    </div>
    <div class="form-group">
      <div>
      <label>Mentor ID:</label>
      </div>
     <input type="text" name="stdID" placeholder="Enter Student Name"> -->
    <!-- </div> -->
    <?php
      // if(isset($student))
      // {
      //     $detail = $student['message'];
      //     echo "<p class='gree'> $detail </p>";
      // }
    ?>
    <!-- <input type="submit" name="submit" >
    </div>
    <div class="col-4">
      <h1>Student Mentors:</h1>
      <form action="<?php echo URLROOT. 'pages/save' ?>" method="post">
<div class="form-group">
  <div>
    <label>Mentor Id:</label>
  </div>
  <div class="form-group">
  <input type="number" name="id" placeholder="Enter Mentor Id">
  </div>
  <input type="submit" name="disp"  value ="print" >
</div>
</form>
    </div>
  </div>
</div> -->

  </body>
  <script>

if ( window.history.replaceState ) { 
        window.history.replaceState( null, null, window.location.href ); 
    } 
  </script>
  </html>
  

<?php require APPROOT . '/views/inc/footer.php'; ?>