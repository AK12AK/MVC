<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Login</title>
    <link rel="stylesheet" href="style.css"/>
    <style>
  
    </style>
        <link rel="stylesheet" href="<?php echo URLROOT . 'css/login.css'?>"/>
</head>
<body>

    <form class="form"  action="<?php echo URLROOT . 'pages/login' ?>" method="post" name="login">
        <h1 class="login-title">Login</h1>
        <input type="text" class="login-input" name="username" placeholder="Username" autofocus="true"/>
        <input type="password" class="login-input" name="password" placeholder="Password"/>
        <input type="submit" value="Login" name="submit" class="login-button"/>
        <?php if(isset($data))
        {
            $data = $data['message'];
            echo "<p  style='color:red;'> $data </p>";
        } ?>
        <p class="link"><a href="registration.php">New Registration</a></p>
  </form>

</body>
</html>