<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <style>
        .bg-custom-1 {
  background-color: #85144b;
}

.bg-custom-2 {
    background: #23d5ab;
}
    </style>
    <nav class="navbar navbar-expand-lg navbar-light bg-light bg-custom-2">
    <img src="<?php echo URLROOT .  'image/123.png' ?>" alt="" style = "width: 80px;">
  
  <!-- <a class="navbar-brand" href="#">Navbar</a> -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item " style="display: flex; margin-left:1em;" >
      <i class="fas fa-graduation-cap" style="margin-top:0.5em;"></i>
        <a class="nav-link" href="<?php echo URLROOT. 'pages/mentor' ?>">Mentor Registration <span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item"  style="display: flex;  margin-left:1em;">
     <i class=" fas fa-user-tie"style="margin-top:0.5em;"> </i>
        <a class="nav-link " href="<?php echo URLROOT. 'pages/student_details' ?>">Student Registration</a>
      </li>

      <li class="nav-item"  style="display: flex;  margin-left:1em;">
     
      <i class=" fas fa-hand-point-right" style="margin-top:0.5em;"></i>
        <a class="nav-link " href="<?php echo URLROOT. 'pages/table' ?>">Student Table</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" action="<?php echo URLROOT. 'pages/logout' ?>" method="post"> 
<?php
    session_start();
    if(isset($_SESSION['user']))
    {
        ?>
     <i class="fa fa-user" aria-hidden="true"></i>
      <button class="btn" type="submit" name="logout">Logout</button>

      <?php
    }
     else

     {
     ?>
      <button class="btn" type="submit">Login</button>

      <?php

     }
     ?>
    </form>
  </div>
</nav>
</head>
<body>
    
</body>
</html>
