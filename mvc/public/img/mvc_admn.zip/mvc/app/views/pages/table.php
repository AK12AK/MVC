<?php
    session_start();
    if(!isset($_SESSION["user"])) {
        header("Location: login.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
     integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
     <link rel="stylesheet" href="<?php echo URLROOT . 'css/teacher.css'?>"/>
     <?php
    include('nav.php');
?>    

</head>
<body>
<?php
// if(isset($_GET['page']))
// {
//     $page  = $_GET["page"]; 
// }
// else
// {
//     $page=1;
// }

// $start_from = ($page-1) * $limit;  

// print_r($start_from);
?>
<div class="container">
  <div class="row justify-content-md-center">
      <form action="<?php echo URLROOT. 'pages/tables' ?>" method="post">
      <div  class="form-group" style="margin-top: 7em;">
      <h1>Student Mentors:</h1>
<div class="form-group">
  <div>
    <label>Mentor Id:</label>
  </div>
  <div class="form-group">
  <input type="number" name="id" placeholder="Enter Mentor Id" required>
  </div>
  </div>

  <div class="form-group" style="display: flex;">

  <select type="text" name="pagination" id="no" style="margin-right: 30px;">
        <option value="">select table</option>
        <option value="5">5</option>
        <option value="10">10</option>
        <option value="20">20</option>
    </select>
  <button class="button-25" type="submit" name="disp" role="button" >Print</button>

</div>
</form>
<div class="test"> 
<?php

if(isset($data))
$data1 = $data[0]->name;
$dd = (array) $data;
// var_dump($dd);
echo "<h2>Mentor name: $data1</h2>";

// var_dump($data);

{
?>
<table>
    <tr class="table-header">
        <th class="col col-1">
            Student name
        </th>
       
        <th class="col col-1">
            Session start
        </th>
        <th class="col col-1">
            Session end
        </th>
    </tr>
    
   
    <?php
    foreach($dd as $dd1)
{
    echo '<tr class="table-row">';

       echo '<td class="col col-1">' . $dd1->std_name . '</td>';

       echo '<td class="col col-1"> 10AM </td>';
       echo '<td class="col col-1">2PM</td>';
    ?>
       </tr>
    <?php
}
?>
</table>
<?php
}

?>
  </div>
</div>
</div>
<!-- <script>
   window.addEventListener('load', (event) => {
   alert("Ddfs");
});
</script> -->
</body>
</html>