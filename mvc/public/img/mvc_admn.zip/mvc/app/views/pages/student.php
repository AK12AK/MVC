<?php
    session_start();
    if(!isset($_SESSION["user"])) {
        header("Location: login.php");
        exit();
    }
?>
`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
     integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
     <link rel="stylesheet" href="<?php echo URLROOT . 'css/teacher.css'?>"/>
     <script type="text/javascript" src="<?php echo URLROOT . 'js/table.js'?>"></script>
     <style>
         nav.navbar.navbar-expand-lg.navbar-light.bg-light {
    margin-top: -22px;
}
</style>
</head>
<?php
    include('nav.php');
?>    
  </head>
<body>
<div class="container">
  <div class="row justify-content-md-center">
    <form action="<?php echo URLROOT. 'pages/student_save' ?>" method="post">
    <div  class="form-group" style="margin-top: 7em;">
    <h1>Student Registration</h1>
  </div>
      <label>Student Name:</label>
      <div class="form-group">
    <input type="text" name="student" id="student" placeholder="Enter Student Name" required>
      </div>
    <div class="form-group">
     
      <label>Mentor ID:</label>
      <div class="form-group">
     <input type="text" id="sudent_form" name="stdID" placeholder="Enter Mentor Id" required> 

      </div>
      <div class="mess">
    
    <?php
    if(isset($_POST['submit']))
    {
      if(isset($data))
      {
          
          $detail = $data['data'];
        //   print_r($data);
        //   exit;
          echo "<p > $detail </p>";
      }
    }
     
    ?>
      </div>
    <!-- <input type="submit" name="submit" > -->
    <button class="button-251" type="submit" name="submit" role="button">Submit</button>
    </div>
    </form>
  </div>
   <script>
  
</script> 
</body>
</html>