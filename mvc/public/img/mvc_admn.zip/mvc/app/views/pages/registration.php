<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>
    <style>
     
    </style>
    <link rel="stylesheet" href="<?php echo URLROOT . 'css/register.css'?>"/>
</head>
<body>
    <div class="form-group">
   
    <form class="form" action="<?php echo URLROOT . 'pages/register' ?>" method="post">
        <h1 class="login-title">Registration</h1>
        <input type="text" class="login-input" name="username" placeholder="Username"  />
        <input type="text" class="login-input" name="email" placeholder="Email Adress">
        <input type="password" class="login-input" name="password" placeholder="Password">
        <input type="submit" name="submit" value="Register" class="login-button">
        <?php if(isset($data))
      {
          $data = $data['message'];
          echo "<p  style='color:green;'> $data </p>";
      }
        ?>
        <p class="link"><a href="<?php echo URLROOT . 'pages/login' ?>">Click to Login</a></p>
    </form>
    </div>
   

</body>
</html>