setTimeout(function(){

    document.getElementsByClassName("mess")[0].style.visibility = "hidden";
  }, 3000); 


if ( window.history.replaceState ) { 
    window.history.replaceState( null, null, window.location.href ); 
} 